import axios from "axios";
import apiConfig from "../apiConfig";
const userEdit=async(token,id,value)=>{
    try{
        const {data}=await axios({
            method:"PUT",
            url:apiConfig.userEdit,
            headers:{
                authorization:`Bearer ${token}`
            },
             data:{id:id,...value},
            params:{
                id:id
            }
            })
            return data;
    }catch(err){
        console.log(err);
    }
  
}