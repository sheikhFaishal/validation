import axios from "axios";
import apiConfig from "../apiConfig";
const userDelete=async(token,id)=>{
    try{
        const {data}=await axios({
            method:"DELETE",
            url:apiConfig.userDelete,
            headers:{
                authorization:`Bearer ${token}`
            },
             data:{
                id:id
            },
            // params:{
            //     id:id
            // }
            })
            return data;
    }catch(err){
        console.log(err);
    }
  
}