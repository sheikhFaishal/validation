import React, { lazy } from "react";
import { Redirect } from "react-router-dom";
//import HomeLayout from "src/layouts/HomeLayout";
import LoginLayout from "./layouts/LoginLayout";

export const routes = [

  {
    exact: true,
    path: "/",
    //layout: HomeLayout,
  layout:LoginLayout,
    component: lazy(() => import("src/views/pages/Home/Login")),
  },
  {
    exact: true,
    path: "/Login",
  //  layout: HomeLayout,
  layout:LoginLayout,
    component: lazy(() => import("src/views/pages/Home/Login")),
  },
  {
    exact: true,
    path: "/",
    //layout: HomeLayout,
  layout:LoginLayout,
    component: lazy(() => import("src/views/pages/Home/Sigup")),
  },
 
  {
    exact: true,
    path: "/Sigup",
    //layout: HomeLayout,
  layout:LoginLayout,
    component: lazy(() => import("src/views/pages/Home/Sigup")),
  },
  {
    exact: true,
    path: "/Otp",
    //layout: HomeLayout,
  layout:LoginLayout,
    component: lazy(() => import("src/views/pages/Home/Otp")),
  },
 
  {
    exact: true,
    path: "/Reset",
    //layout: HomeLayout,
  layout:LoginLayout,
    component: lazy(() => import("src/views/pages/Home/Reset")),
  },
  {
    exact: true,
    path: "/Otpforgot",
    //layout: HomeLayout,
  layout:LoginLayout,
    component: lazy(() => import("src/views/pages/Home/Otpforgot")),
  },
  {
    exact: true,
    path: "/Forgot",
    //layout: HomeLayout,
  layout:LoginLayout,
    component: lazy(() => import("src/views/pages/Home/Forgot")),
  },
  
 {
    exact: true,
    path: "/404",
    component: lazy(() => import("src/views/errors/NotFound")),
  },
  {
    component: () => <Redirect to="/404" />,
  },
];
