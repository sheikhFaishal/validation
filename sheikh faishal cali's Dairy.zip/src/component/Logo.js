import React from 'react';

const Logo = (props) => {
  return <img src="/images/dairy.png" alt="Logo" {...props} />;
};

export default Logo;
