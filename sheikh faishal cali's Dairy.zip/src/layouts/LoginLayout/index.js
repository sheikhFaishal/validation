import React from "react";
import PropTypes from "prop-types";
import {
  makeStyles,
  Grid,
  Box,
  Typography,
  Container,
} from "@material-ui/core";
import Logo from "src/component/Logo";
import { useHistory } from "react-router-dom";
import TopBar from "src/layouts/HomeLayout/TopBar"


const useStyles = makeStyles((theme) => ({
  headbox: {
    backgroundColor: theme.palette.background.default,
    margin: "0",
    padding: "0",
   backgroundImage:"url('images/background.png')",
   backgroundRepeat:"no-repeat",
    backgroundPosition:"center",
    backgroundSize:"cover",
    color:"#000",
   

    
  },
  content: {
    height:"100%",

    padding: "0",
   display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  imgbox: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
   
    backgroundSize: "cover",
    backgroundPosition: "center",
  
    [theme.breakpoints.down("sm")]: {
      display: "none",
    },
    
  },
  LogoIcon: {
    cursor: "pointer",
  
  },
}));

const LoginLayout = ({ children }) => {
  const classes = useStyles();
  const history = useHistory();
  return (
    <>
      <Box className={classes.headbox}>
        <Box>
          <TopBar/>
        </Box>
        <Grid container spacing={0} alignItems="center" justifyContent="center">
          <Grid item xs={12} md={6} >
            <Box className={classes.imgbox}>
              <Box className={classes.LogoIcon} onClick={() => history.push("/")}>
                <img src="images/dog.png"  width="100%" alt="Logo Image"/>
                
                </Box>
                
            </Box>
            <Box justifyContent="center" textAlign="center" alignItems="center">
            <Typography variant="h2">Cali’s Dairy</Typography>
            
            <Typography variant="body1">Find, Connect & Buy</Typography>
            </Box>
          </Grid>
          <Grid item xs={12} md={6}>
            <Container maxWidth="sm">
              <Box className={classes.content}>
                <Box style={{ width: "100%" }}>{children}</Box>
              </Box>
            </Container>
          </Grid>
        </Grid>
      </Box>
    </>
  );
};

LoginLayout.propTypes = {
  children: PropTypes.node,
};

export default LoginLayout;
