import {
  Container,
  Typography,
  Box,
  Grid,
  makeStyles,
  Button,
} from "@material-ui/core";

import Link from "@material-ui/core/Link";
import FormHelperText from "@material-ui/core/FormHelperText";
import React, { useState, useEffect, useContext } from "react";
//import { toast } from "react-toastify";
import moment from "moment";
//import { calculateTimeLeft } from "./timer";
// import ButtonCircularProgress from "src/component/ButtonCircularProgress";

import {
  formik,
  form,
  field,
  errorMessage,
  Form,
  Formik,
  yupToFormErrors,
} from "formik";
import axios from "axios";
//mport ApiConfig from "src/config/Apiconfig";
import * as Yup from "yup";
import { Visibility, VisibilityOff } from "@material-ui/icons";
import { useHistory } from "react-router-dom";
import { AuthContext } from "src/context/Auth";
const useStyles = makeStyles((theme) => ({
  mainbox: {
    textAlign: "center",
    justifyContent: "center",
    alignItems: "center",
  },

  container1: {
    //width: "100%",
    //height:"100%",
    //margin: "30px 0px",
    //justifyContent: "center",
    marginTop: "80px",

    borderRadius: "5px",
    background: "rgba(255, 255, 255, 0.6)",
    boxShadow: "0px 0px 26px rgba(0, 0, 0, 0.1)",
    borderRadius: "20px",
    padding: "50px",
    minHeight: "335px",
    maxHeight: "350px",
    width: "100%",
    paddingTop: "210px",
    [theme.breakpoints.down("md")]: {
      padding: "50px",
    },
  },

  typo2: {
    fontSize: "20px",
    fontFamily: "Roboto",
    display: "flex",
  },
  btn1: {
    maxWidth: "90%",
    paddingTop: "10px",
    paddingBottom: "10px",
    fontWeight: 300,
    fontSize: "16px",
    borderRadius: "10px",
  },
  btn2: {
    backgroundColor: "#F2CB6A",
  },

  textfield: {
    width: 60,
    height: 45,
    textAlign: "center",
    marginLeft: 10,
    fontSize: 20,
    border: "none",
    "@media(max-width:463px)": {
      width: "36px",
    },
    background: "#F3F2F9",
    borderRadius: "10px",

    "& .MuiOutlinedInput-input": {
      textAlign: "center",
      padding: "21.5px 15px",
    },
  },
  typo1box: {
    //display: "flex",
    //flexDirection: "column",
    //textAlign: "center",
    //alignItems: "centre",
    width: "100%",
  },

  fpbox: {
    display: "flex",
    justifyContent: "flex-end",
  },
  gobackbox: {
    width: "100%",
    justifyContent: "flex-start",
    display: "flex",
    margin: "10px 50px",
  },

  timerbox: {
    width: "83%",
    display: "flex",
    justifyContent: "space-between",
    textAlign: "end",
  },
  timertypo: {
    color: "green",
    margin: "10px 0px",
    fontSize: "14px",
  },
  mainsec: {
    width: "100%",
    "& .second": {
      background: "#ffffff",
      width: "100%",
    },
  },
  bothGrid: {
    width: "100%",
    height: "100vh",
    justifyContent: "center",
    background: "#F5F5F5",
    "@media(max-width:960px)": {
      display: "none",
    },
    "& img": {
      maxWidth: "231px",
      width: "100%",
    },
    "& .boyBox": {
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      "& img": {
        maxWidth: "329px",
        width: "100%",
      },
    },
    "& .typoBox": {
      width: "100%",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      "& h1": {
        fontWeight: 200,
        paddingTop: "10px",
        fontSize: "43px",
        "@media(max-width:327px)": {
          fontSize: "35px",
        },
      },
    },
  },
  firstGrid: {
    paddingLeft: "50px",
    paddingTop: "2rem",
  },

  secondGrid: {
    paddingLeft: "40px",
    paddingRight: "40px",
    "& .headingBox": {
      "@media(max-width:960px)": {
        paddingTop: "20px",
      },
    },
    "& h2": {
      fontWeight: 700,
      color: "#317BCD",
      paddingBottom: "5px",
    },
    "& h6": {
      fontWeight: 300,
      paddingBottom: "15px",
    },
  },
  formControl: {
    "& .MuiOutlinedInput-root": {
      borderRadius: "10px",
    },
  },
}));

function Forget() {
  const classes = useStyles();
  const history = useHistory();
  const [checked, setChecked] = React.useState(false);
  const [isPromoted, setisPromoted] = useState(false);
  const [isSubmit, setIsSubmit] = useState(false);
  const [check, setcheck] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [otpError, setOtpError] = useState(false);
  const [otp, setOtp] = useState(new Array(4).fill(""));
  console.log("otp---", otp[0]);
  const [fieldIndex, SetfieldIndex] = useState();
  const auth = useContext(AuthContext);
  console.log("yi9huthfjfiog", auth);
  const [isLoading, setLoader] = useState(false);
  const [isloading, setloader] = useState(false);

  const handleOtp = (element, index) => {
    setOtp([...otp.map((d, idx) => (idx === index ? element.value : d))]);

    if (element.nextSibling) {
      element.nextSibling.focus();
    }
  };
  const handleShow2 = (e) => {
    var get = document.getElementById("demo2");
    get.style.display = "none";
  };

  const _onBackSpace = (e) => {
    const keyCode = e.keyCode;
    const prev = e.target.previousSibling;
    if (keyCode === 8 && prev !== null) {
      setTimeout(() => {
        prev.focus();
      });
    }
  };

  // const otpVerify = async () => {
  //   const vari = otp.toString();
  //   if (vari === ",,,,,") {
  //     setOtpError(true);
  //     return;
  //   }
  // };

  // const formInitialvalue = {
  //   otp: "",
  // };

  // const vari = otp.toString();
  // if (vari === ",,,,,") {
  //   setOtpError(true);
  //   return;
  // }
  const fromValidation = Yup.object().shape({
    otp: Yup.string()
      .required("OTP is required")
      .matches(/^[0-9]*$/, "Must be a valid OTP")
      .max(4, "Should not exceeds 4 digits")
      .min(4, "Must be only 4 digits"),
  });

  console.log("lskjflks", window.location);
  const handleFormSubmit = async (values) => {
    console.log("values-----", values);
    try {
      setLoader(true);

      const res = await axios({
        method: "GET",

        data: {
          code: parseInt(values.otp),
        },
        params: {
          token: `${otp[0]}${otp[1]}${otp[2]}${otp[3]}`,
        },
      });
      if (res.data.status === 200) {
        // toast.success("OTP has been verified.");
        setLoader(false);
        setIsSubmit(true);

        history.push({
          pathname: "/Changepass",
          state: { email: values.email, otp: values.otp },
        });
      } else {
        setLoader(false);
        // toast.warn(res.data.message);
      }
    } catch (error) {
      setLoader(false);
      if (error.response) {
        // toast.error(error.response.data.message);
      } else {
        // toast.error(error.message);
      }
    }
  };
  const resendotphandle = async (values) => {
    try {
      setloader(true);

      const res = await axios({
        method: "POST",

        params: {
          email: values.email,
        },
      });
      if (res.data.status === 200) {
        // toast.success(res.data.message);
        setloader(false);
        setIsSubmit(true);
        auth.setEndtime(moment().add(3, "m").unix());
      } else {
        setloader(false);
        //toast.warn(res.data.message);
      }
    } catch (error) {
      setloader(false);
      if (error.response) {
        //toast.error("Please enter the correct Email");
      } else {
        // toast.error(error.message);
      }
    }
  };

  return (
 
      <Box className={classes.mainsec}>
        <Grid item xs={12} sm={12} md={12} lg={6}>
          <Box className={classes.container1}>
          
              <Typography variant="h4" className={classes.typo1}>
                Verify OTP
              </Typography>
        
            <Box>
              <Typography
                variant="body1"
                style={{
                  lineHeight: "14px",
                  fontSize: "12px",
                  padding: "0px 10px ",
                  fontFamily: "Inter",
                  fontWeight: 400,
                }}
              >
                OTP has been sent to abc@gmail.com Please enter the OTP. &nbsp;
              </Typography>
            </Box>

            <Box className={classes.topbox}>
              <Formik
                // initialValues={formInitialvalue}
                initialStatus={{
                  success: false,
                  successMed: "successfull",
                }}
                // validationSchema={fromValidation}
                // onSubmit={(values) => handleFormSubmit(values)}
              >
                {({
                  errors,
                  handleBlur,
                  handleChange,
                  handleSubmit,
                  touched,
                  values,
                  setFieldValue,
                  o,
                }) => (
                  <Form
                    onSubmit={handleSubmit}
                    style={{ width: "100%" }}
                    className={classes.formControl}
                  >
                    <Box
                      style={{
                        display: "flex",
                        width: "100%",
                        justifyContent: "center",
                      }}
                    >
                      {otp &&
                        otp?.map((data, index) => {
                          {
                            console.log("otp+++", otp);
                          }
                          return (
                            <input
                              className={classes.textfield}
                              name="otp"
                              type="text"
                              maxLength="1"
                              error={Boolean(touched.otp && errors.otp)}
                              label=""
                              variant="outlined"
                              key={index}
                              value={data}
                              onChange={(e) => handleOtp(e.target, index)}
                              onKeyDown={_onBackSpace}
                              onBlur={handleBlur}
                            ></input>
                          );
                        })}
                    </Box>

                    <FormHelperText
                      style={{ color: "red", marginLeft: "53px" }}
                    >
                      {touched.otp && errors.otp}
                    </FormHelperText>
                    <Box className={classes.timerbox}>
                      {/* <Box>
                                <Typography
                                  variant="body1"
                                  style={{
                                    color: "red",
                                    fontSize: "12px",
                                    fontWeight: 500,
                                  }}
                                >
                                  OTP will expire in {auth.timeLeft?.minutes} m :{" "}
                                  {auth.timeLeft?.seconds} s
                                </Typography>{" "}
                              </Box> */}
                    </Box>

                    <Grid item lg={12} md={12} xs={12} sm={12}>
                      <Box mt={8}>
                        <Button
                          variant="outlined"
                          fullWidth
                          color="#fff"
                          style={{
                            padding: "10px",
                            backgroundColor: "#6FCFB9",
                            color: "white",
                            borderRadius: "12px",
                            width: "100%",
                          }}
                          type="submit"
                          component={Link}
                          to="/Login"
                        >
                          Verify OTP
                        </Button>
                      </Box>
                    </Grid>
                  </Form>
                )}
              </Formik>
            </Box>
          </Box>
        </Grid>
      </Box>
  );
}

export default Forget;
