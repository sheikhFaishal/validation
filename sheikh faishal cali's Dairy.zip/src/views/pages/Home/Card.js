import React from "react";
import { Box, Container, Grid, } from "@material-ui/core";
import { makeStyles } from "@material-ui/core";

const useStyles = makeStyles((theme) => ({
  bannerbox: {
    color: "#000",
    paddingBottom: "30px",
    background: "#f5f5f5",
  },
  imageBox: {
    padding: "20px",
  },
  bannerboxx: {
    paddingTop: "10px",
    color: "#000",
    paddingBottom: "30px",
    background: "#ffff",
  },
}));

export default function Card() {
  const classes = useStyles();
  return (
    <Grid item xs={12} md={12}>
      <Box className={classes.bannerbox}>
        <Container maxWidth="md">
          <Box className={classes.bannerboxx}>
            <Box className={classes.imageBox}></Box>
          </Box>
        </Container>
      </Box>
    </Grid>
  );
}
