import React from "react";
import { Box, Container, Grid, Typography } from "@material-ui/core";
import { makeStyles } from "@material-ui/core";
import Avatar from "@material-ui/core/Avatar";

import AvatarGroup from "@material-ui/lab/AvatarGroup";
import { BiShare } from "react-icons/bi";
import { AiOutlineHeart } from "react-icons/ai";
import { BiCommentDetail } from "react-icons/bi";
const useStyles = makeStyles((theme) => ({
  bannerbox: {
  
    color: "#000",
    paddingBottom: "30px",
    background: "#f5f5f5",
   
  },
  imageBox: {
  
    minHeight: "210px",
   
    padding: "20px",
  },
  bannerboxx: {
    paddingTop: "10px",
    color: "#000",
    paddingBottom: "30px",
    background: "#ffff",
  },
  textBox: {
    width: "100%",
    marginTop: "15px",
  },
  iconsBox: {
    display: "flex",
    justifyContent: "space-between",
    paddingBottom: "10px",
   
    padding: "14px 10px",
  },
}));

export default function Homepara() {
  const classes = useStyles();
  return (
    <Grid item xs={12} md={12}>
      <Box className={classes.bannerbox}>
        <Container maxWidth="md">
          <Box className={classes.bannerboxx}>
            <Box className={classes.imageBox}>
              <Box display="flex">
                <Box>
                  <Avatar alt="Remy Sharp" src="/images/umar.png" />
                </Box>
                <Box paddingLeft="10px">
                  <Typography variant="h5"> Umair Siddiqui</Typography>
                  <Typography variant="body1">2h ago</Typography>
                </Box>
              </Box>
              <Box className={classes.textBox}>
                <Typography variant="body1">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Adipiscing tincidunt ac sed egestas. Ultrices Lorem ipsum
                  dolor sit amet, consectetur adipiscing elit. Adipiscing
                  tincidunt ac sed egestas. Ultrices...
                </Typography>
              </Box>

              <Box paddingTop="15px">
                <img src="images/parrort.png" alt="images" width="100%" />
              </Box>
              <Box display="flex" justifyContent="space-between" margin="10px">
                <Box display="flex">
                  <AvatarGroup max={4}>
                    <Avatar alt="Remy Sharp" src="/images/av.png" />
                    <Avatar alt="Travis Howard" src="/images/ava.png" />
                    <Avatar alt="Cindy Baker" src="/images/avaa.png" />
                  </AvatarGroup>
                </Box>

                <Box display="flex" mt={2}>
                  <Box paddingRight="12px">
                    <Typography variant="body2">3 Comments</Typography>
                  </Box>
                  <Typography variant="body2">17 Share</Typography>
                </Box>
              </Box>
              <Box className={classes.iconsBox}>
                <Box display="flex">
                  <Typography variant="body1">Like</Typography>
                  <AiOutlineHeart />
                </Box>
                <Box display="flex">
                  <BiCommentDetail />
                  <Typography variant="body1">Comments</Typography>
                </Box>
                <Box display="flex">
                  <BiShare />
                  <Typography variant="body1">Share</Typography>
                </Box>
              </Box>
              <Box>
              </Box>
            </Box>
          </Box>
        </Container>
      </Box>
    </Grid>
  );
}
