import React from "react";
import { Box, } from "@material-ui/core";
import Page from "src/component/Page";
//import Banner from "./Sigup";
//import Home1 from "./Home";
//import Homepara from "./Homepara";
//import Homepage from "./Homepage";
//import Card from "./Card";

function Home(props) {
  return (
    <Page title="Cali’s Dairy| MetaArts">
      <Box>
        {/*  <Banner />*/}
  
        
      {/* <Home1 />
        <Card/>
        <Homepage />
  <Homepara />*/}


     
      </Box>
    </Page>
  );
}

export default Home;
