import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Container,
  Grid,
  Button,
  Checkbox,
  TextField,
  InputLabel,
  FormHelperText,
  InputAdornment,
  OutlinedInput,
  IconButton,
  MenuItem,
  Select,
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core";

import "animate.css";

import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormControl from "@material-ui/core/FormControl";
import { Form, Formik } from "formik";
import Radio from "@material-ui/core/Radio";
import Visibility from "@material-ui/icons/Visibility";
import VisibilityOff from "@material-ui/icons/VisibilityOff";
import { Link } from "react-router-dom";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormLabel from "@material-ui/core/FormLabel";

import * as yep from "yup";
import axios from "axios";
const useStyles = makeStyles((theme) => ({
  bannerbox: {
    paddingTop: "30px",
    color: "#000",
    paddingBottom: "70px",
  },
  mainbox: {
    background: "rgba(255, 255, 255, 0.6)",
    boxShadow: "0px 0px 26px rgba(0, 0, 0, 0.1)",
    borderRadius: "20px",
    padding: "60px",
  },
  textBox: {
    background: "#ffff",
   borderRadius:"8px",
  },
  radio: {
    borderRadius: "8px",
    height: "47px",
    // display: "flex",
    alignItems: "center",
    width: "100%",
    // justifyContent: "space-between",
    [theme.breakpoints.down("xs")]: {
      height: "35px",
    },
    "&:hover": {
      borderColor: "#fff",
    },
    "& .innerRadio": {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
    },
  },
  
}));
function Banner() {
  const classes = useStyles();

  const [city, setCity] = useState("");
  const [showCities, setShowCities] = useState([]);

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setshowConfirmPassword] = useState(false);
  const [cities, setCities] = useState([]);

  const [countries, setCountries] = useState([]);

  const [showStates, setShowStates] = useState([]);
  const [country, setCountry] = React.useState("");

  const [value, setValue] = React.useState("female");

  const handleChange1 = (event) => {
    setValue(event.target.value);
  };

  const [states, setStates] = useState([]);
  const formInitialSchema = {
    fullname: "",
    email: "",
    password: "",
    confirmPassword: "",
    selectcountry: "",
    phone: "",
    address: "",
    state: "",
    city: "",
    zip: "",
    country: "",
  };

  const formValidationSchema = yep.object().shape({
    fullname: yep
      .string()
      .required("Full Name is required.")
      .matches(/^([A-Za-z\s]*)$/gi, "Name can only alphabet letters.")
      .min(2, "Should be 2 character long.")
      .max(24, "should not exceed 20 characters."),
    email: yep
      .string()
      .email("Please enter a valid email address.")
      .required("Email is required."),
    password: yep
      .string()
      .required("Password is required.")
      .matches(
        /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/,
        "Please enter a strong password"
      )
      .min(6, "Please enter atleast 6 characters.")
      .max(16, "You can enter only 16 characters."),
    confirmPassword: yep
      .string()
      .required("Confirm password is required.")
      .oneOf(
        [yep.ref("password"), null],
        "Confirm password or password did not match."
      ),
    selectcountry: yep.string().required("Please select country."),
    phone: yep
      .string()
      .required("Phone number is required.")
      .max(10, "Should not exceed 10 characters.")
      .min(10, "Please enter a valid phone number."),

    address: yep.string().required("Address is required."),

    zip: yep
      .string()
      .required("zip is reqired")
      .max(10, "Should not exceed 10 characters.")
      .min(6, "Please enter a valid zip."),

    country: yep.string()
    .required("Select Country"),
    state: yep.string()
    .required("Select state"),
    city: yep.string()
    .required("Select city"),
  });

  const changeCountry = (e) => {
    const name = e.target.value;
    changeCountryList(name);
  };

  const changeStateList = (name) => {
    const selectted = states.filter((cont) => {
      return cont.name === name;
    });

    if (selectted.length !== 0) {
      const contId = selectted[0]?.id;
      console.log("contId---", contId);
      const allCity = cities.filter((city) => {
        return city.state_id === contId;
      });
      setShowCities(allCity);
    }
  };

  const changeState = (e) => {
    const name = e.target.value;
    changeStateList(name);
  };

  const changeCountryList = (name) => {
    const selectted = countries?.filter((cont) => {
      return cont.name === name;
    });

    const contId = selectted[0]?.id;
    const allState = states?.filter((state) => {
      return state.country_id === contId;
    });
    setShowStates(allState);
  };

  useEffect(() => {
    axios.get("/json/countries.json").then(function (response) {
      setCountries(response.data.countries);
      axios.get("/json/states.json").then(function (response) {
        setStates(response.data.states);
        axios.get("/json/cities.json").then(function (response) {
          setCities(response.data.cities);
        });
      });
    });
  }, []);

  return (
    <Box className={classes.bannerbox}>
      <Container maxWidth="lg">
        <Box className={classes.mainbox}>
          <Formik
            initialValues={formInitialSchema}
            initialStatus={{
              success: false,
              successMsg: "",
            }}
            validationSchema={formValidationSchema}
          >
            {({
              errors,
              handleBlur,
              handleChange,
              handleSubmit,
              touched,
              values,
              setFieldValue,
            }) => (
              <Form>
                <Grid container spacing={2}>
                  <Box>
                    <Typography variant="h2">Create New Account</Typography>
                    <br />
                    <Typography variant="body1">Explore Pets World</Typography>
                  </Box>
                  <Grid item lg={12} md={12} xs={12} sm={12}>
                    <Box mt={2}>
                      <Box paddingBottom="5px">
                        <Typography variant="body2"> Full Name</Typography>
                      </Box>
                      <TextField
                        type="text"
                        className={classes.textBox}
                        placeholder="Full Name"
                        variant="outlined"
                        fullWidth
                        name="fullname"
                        id="fullname"
                        value={values.fullname}
                        error={Boolean(touched.fullname && errors.fullname)}
                        onBlur={handleBlur}
                        onChange={handleChange}
                      />

                      <FormHelperText error>
                        {touched.fullname && errors.fullname}
                      </FormHelperText>
                    </Box>
                  </Grid>
                  <Grid item lg={12} md={12} xs={12} sm={12}>
                    <Box>
                      <Box paddingBottom="5px">
                        <Typography variant="body2"> Email address</Typography>
                      </Box>
                      <TextField
                        type="text"
                        className={classes.textBox}
                        placeholder="Email address"
                        variant="outlined"
                        fullWidth
                        name="email"
                        id="email"
                        value={values.email}
                        error={Boolean(touched.email && errors.email)}
                        onBlur={handleBlur}
                        onChange={handleChange}
                      />

                      <FormHelperText error>
                        {touched.email && errors.email}
                      </FormHelperText>
                    </Box>
                  </Grid>
                  <Grid item lg={12} md={12} xs={12} sm={12}>
                    <Box>
                      <Box paddingBottom="5px">
                        <Typography variant="body2"> Phone Number</Typography>
                      </Box>
                    
                      <FormControl style={{ width: "100%" }}>
                        <OutlinedInput
                          name="phone"
                          value={values.phone}
                          error={Boolean(touched.phone && errors.phone)}
                          onBlur={handleBlur}
                          onChange={handleChange}
                          id="outlined-adornment-amount"
                          className={classes.textBox}
                          placeholder="Enter phone number"
                          startAdornment={
                            <InputAdornment position="start">
                              <InputLabel>
                                {" "}
                                <span style={{ color: "rgb(103, 103, 103)" }}>
                                  {" "}
                                </span>{" "}
                              </InputLabel>
                            </InputAdornment>
                          }
                        />
                      </FormControl>
                    
                      <FormHelperText error className={classes.helperText}>
                        {touched.phone && errors.phone}
                      </FormHelperText>
                    </Box>
                  </Grid>
                 
                  <Grid item lg={12} md={12} xs={12} sm={12}>
                    <Box display="flex" width="100%">
                      <FormControl component="fieldset">
                        <FormLabel component="legend">Gender</FormLabel>
                        <RadioGroup
                          aria-label="gender"
                          name="gender1"
                          value={value}
                          onChange={handleChange1}
                        >
                        <Box style={{paddingRight:"100px"}}>
                            <FormControlLabel
                              value="male"
                              control={<Radio style={{ color: "#6FCFB9" }} />}
                              label="Male"
                            />
                            </Box>
                         
                            <FormControlLabel
                              value="female"
                              control={<Radio style={{ color: "#6FCFB9" }} />}
                              label="Female"
                            />
                        
                        </RadioGroup>
                      </FormControl>
                    </Box>
                  </Grid>
                  <Grid item lg={12} md={12} xs={12} sm={12}>
                    <Box>
                      <Box paddingBottom="5px">
                        <Typography variant="body2">
                          Residential address
                        </Typography>
                      </Box>
                      <TextField
                        type="text"
                        className={classes.textBox}
                        placeholder="Residential Address"
                        variant="outlined"
                        fullWidth
                        name="address"
                        id="address"
                        value={values.address}
                        error={Boolean(touched.address && errors.address)}
                        onBlur={handleBlur}
                        onChange={handleChange}
                      />

                      <FormHelperText error>
                        {touched.address && errors.address}
                      </FormHelperText>
                    </Box>
                  </Grid>
                  <Grid item lg={6} md={6} xs={6} sm={6}>
                    <Box>
                      <Box paddingBottom="5px">
                        <Typography variant="body2">Country</Typography>
                      </Box>
                      <Select
                      
                        variant="outlined"
                        displayEmpty
                        inputProps={{ "aria-label": "Without label" }}
                        fullWidth
                        style={{ padding: "4px" }}
                        className={classes.textBox}
                        margin="dense"
                        name="country"
                        value={values?.country}
                        error={Boolean(touched.country && errors.country)}
                        onBlur={handleBlur}
                        onChange={(e) => {
                          handleChange(e);
                          changeCountry(e);
                        }}
                      >
                        <MenuItem value="">Select your country</MenuItem>

                        {countries.map((countries) => {
                          return (
                            <MenuItem
                              key={countries.name + countries.id}
                              value={countries.name}
                            >
                              {countries.name}
                            </MenuItem>
                          );
                        })}
                      </Select>
                      <FormHelperText error>
                      {touched.country && errors.country}
                    </FormHelperText>
                    </Box>
                  </Grid>
                  <Grid item lg={6} md={6} xs={6} sm={6}>
                    <Box>
                      <Box paddingBottom="5px">
                        <Typography variant="body2"> State</Typography>
                      </Box>
                      <Select
                        variant="outlined"
                        style={{ padding: "4px" }}
                        fullWidth
                        className={classes.textBox}
                        name="state"
                        margin="dense"
                        value={values?.state}
                        error={Boolean(touched.state && errors.state)}
                        displayEmpty
                        inputProps={{ "aria-label": "Without label" }}
                        onBlur={handleBlur}
                        onChange={(e) => {
                          changeState(e);
                          handleChange(e);
                        }}
                      >
                        <MenuItem value="">Select your state</MenuItem>
                        {showStates.length !== 0 &&
                          showStates.map((state) => {
                            return (
                              <MenuItem
                                key={state?.name + state?.id}
                                value={state?.name}
                              >
                                {state?.name}
                              </MenuItem>
                            );
                          })}
                      </Select>
                      <FormHelperText error>
                      {touched.state && errors.state}
                    </FormHelperText>
                    </Box>
                  </Grid>

                  <Grid item lg={6} md={6} xs={6} sm={6}>
                    <Box>
                      <Box paddingBottom="5px">
                        <Typography variant="body2">City</Typography>
                      </Box>
                      <Select
                        variant="outlined"
                        displayEmpty
                        inputProps={{ "aria-label": "Without label" }}
                        style={{ padding: "4px" }}
                        fullWidth
                        name="city"
                        className={classes.textBox}
                        margin="dense"
                        value={values.city}
                        error={Boolean(touched.city && errors.city)}
                        onBlur={handleBlur}
                        onChange={(e) => {
                          setCity(e.target.value);
                          handleChange(e);
                        }}
                      >
                        <MenuItem value="">Select your city</MenuItem>
                        {showCities.length !== 0 &&
                          showCities.map((city) => {
                            return (
                              <MenuItem
                                key={city.name + city.id}
                                value={city.name}
                              >
                                {city.name}
                              </MenuItem>
                            );
                          })}
                      </Select>
                      <FormHelperText error>
                      {touched.city && errors.city}
                    </FormHelperText>
                    </Box>
                  </Grid>

                  <Grid item lg={6} md={6} xs={6} sm={6}>
                    <Box>
                      <Box paddingBottom="5px">
                        <Typography variant="body2"> Zip</Typography>
                      </Box>
                      <TextField
                        type="text"
                        className={classes.textBox}
                        placeholder="Enter zip"
                        variant="outlined"
                        fullWidth
                        name="zip"
                        id="zip"
                        value={values.zip}
                        error={Boolean(touched.zip && errors.zip)}
                        onBlur={handleBlur}
                        onChange={handleChange}
                      />

                      <FormHelperText error>
                        {touched.zip && errors.zip}
                      </FormHelperText>
                    </Box>
                  </Grid>
                  <Grid item lg={12} md={12} xs={12} sm={12}>
                  <Box>
                    <Box paddingBottom="5px">
                      <Typography variant="body2"> Password</Typography>
                    </Box>
                    <TextField
                      className={classes.textBox}
                      InputProps={{
                        endAdornment: (
                          <IconButton
                            style={{ color: "#CBCBCB" }}
                            position="end"
                            aria-label="toggle password visibility"
                            onClick={() => setShowPassword(!showPassword)}
                          
                            edge="end"
                          >
                            {showPassword ? (
                              <Visibility />
                            ) : (
                              <VisibilityOff />
                            )}
                          </IconButton>
                        ),
                      }}
                      type={showPassword ? "text" : "password"}
                      placeholder="Password"
                      variant="outlined"
                      fullWidth
                      name="password"
                      id="password"
                      value={values.password}
                      error={Boolean(touched.password && errors.password)}
                      onBlur={handleBlur}
                      onChange={handleChange}
                    />

                    <FormHelperText error>
                      {touched.password && errors.password}
                    </FormHelperText>
                  </Box>
                </Grid>
                <Grid item lg={12} md={12} xs={12} sm={12}>
                  <Box paddingBottom="5px">
                    <Typography variant="body2"> Confirm Password</Typography>
                  </Box>
                  <TextField
                    className={classes.textBox}
                    InputProps={{
                      endAdornment: (
                        <IconButton
                          style={{ color: "#CBCBCB" }}
                          position="end"
                          aria-label="toggle password visibility"
                          onClick={() =>
                            setshowConfirmPassword(!showConfirmPassword)
                          }
                         
                          edge="end"
                        >
                          {showConfirmPassword ? (
                            <Visibility />
                          ) : (
                            <VisibilityOff />
                          )}
                        </IconButton>
                      ),
                    }}
                    type={showConfirmPassword ? "text" : "password"}
                    placeholder="Confirm Password"
                    variant="outlined"
                    fullWidth
                    name="confirmPassword"
                    id="confirmPassword"
                    value={values.confirmPassword}
                    error={Boolean(
                      touched.confirmPassword && errors.confirmPassword
                    )}
                    onBlur={handleBlur}
                    onChange={handleChange}
                  />
                  <FormHelperText error>
                    {touched.confirmPassword && errors.confirmPassword}
                  </FormHelperText>
                </Grid>

                  <Grid
                    item
                    lg={12}
                    md={12}
                    sm={12}
                    xs={12}
                    style={{ display: "flex", justifyContent: "space-between" }}
                  >
                    <Box display="flex" justifyContent="space-between">
                      <FormControlLabel
                        control={<Checkbox name="checkedC" />}
                      />
                      <Box marginTop="10px">
                        <Typography variant="body1">
                          I have read and accept the{" "}
                          <span style={{ color: "rgb(80, 137, 246)" }}>
                            Terms & Conditions
                          </span>{" "}
                          and{" "}
                          <span style={{ color: "rgb(80, 137, 246)" }}>
                            {" "}
                            Privacy Policy
                          </span>
                        </Typography>
                      </Box>
                    </Box>
                  </Grid>
                  <Grid item lg={12} md={12} xs={12} sm={12}>
                    <Button
                      type="submit"
                      variant="outlined"
                      fullWidth
                      color="#fff"
                      style={{
                        padding: "10px",
                        backgroundColor: "#6FCFB9",
                        color: "white",
                        borderRadius: "12px",
                      }}
                      component={Link}
                      to="/Otp"
                    >
                      Create
                    </Button>
                  </Grid>
                </Grid>
              </Form>
            )}
          </Formik>
        </Box>
      </Container>
    </Box>
  );
}

export default Banner;
