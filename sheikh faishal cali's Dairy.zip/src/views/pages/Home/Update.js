import React, { useState, useMemo, useEffect } from "react";
import {
  Box,
  Typography,
  Container,
  Grid,
  Button,
  Checkbox,
  TextField,
  InputLabel,
  FormHelperText,
  InputAdornment,
  OutlinedInput,
  IconButton,
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core";
import "animate.css";
import axios from "axios";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormControl from "@material-ui/core/FormControl";
import { Form, Formik } from "formik";
import { Link } from "react-router-dom";
import Visibility from "@material-ui/icons/Visibility";
import VisibilityOff from "@material-ui/icons/VisibilityOff";

import Radio from "@material-ui/core/Radio";
import * as yep from "yup";
import { useHistory, useLocation } from "react-router-dom";
import { AlignCenter } from "react-feather";
const useStyles = makeStyles((theme) => ({
  bannerbox: {
    paddingTop: "30px",
    color: "#000",
    paddingBottom: "70px",
  },
  mainbox: {
    background: "rgba(255, 255, 255, 0.6)",
    boxShadow: "0px 0px 26px rgba(0, 0, 0, 0.1)",
    borderRadius: "20px",
    padding: "60px",
  },
  textBox:{
    background:"#ffff",
    //borderRadius:"12px",
  },
  updateBox:{
justifyContent:"center",
textAlign:"center",
alignItem:"center",
  }
}));
function Banner() {
  const classes = useStyles();
  const history = useHistory();
  const [value, setValue] = React.useState("female");
  const location = useLocation();
  const referralCode = location.search.split("?")[1];
  const [selectedCountry, setSelectedCode] = useState("91");
  const [isProcessing, setIsProcessing] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setshowConfirmPassword] = useState(false);


  const handleChange = (event) => {
    setValue(event.target.value);
  };
  const formInitialSchema = {
    fullname: "",
    email: "",
    password: "",
    confirmPassword: "",
    selectcountry: "India",
    phone: "",
  };

  const handleFormSubmit = async (values) => {
    try {
      setIsProcessing(true);
      const dataToSend = {
        first_name: values.firstname,
        last_name: values.lastname,
        phone: values.phone,
        user_name: values.username,
        email: values.email,
        password: values.password,
        country: values.selectcountry,
        sponsor: values.sponser,
      };
      const response = await axios({});
      if (response) {
        setIsProcessing(false);
        history.push("/thank-you");
      } else {
        setIsProcessing(false);
      }
    } catch (error) {
      console.log(error);
      setIsProcessing(false);
    }
  };

  const formValidationSchema = yep.object().shape({
    firstname: yep
      .string()
      .required("First name is required.")
      .matches(/^[A-Za-z]+$/, "Only alphabets are allowed.")
      .min(2, "Should be 2 character long.")
      .max(24, "should not exceed 20 characters."),
    email: yep
      .string()
      .email("Please enter a valid email address.")
      .required("Email is required."),
    password: yep
      .string()
      .required("Password is required.")
      .matches(
        /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/,
        "Please enter a strong password"
      )
      .min(6, "Please enter atleast 6 characters.")
      .max(16, "You can enter only 16 characters."),
    confirmPassword: yep
      .string()
      .required("Confirm password is required.")
      .oneOf(
        [yep.ref("password"), null],
        "Confirm password or password did not match."
      ),
    selectcountry: yep.string().required("Please select country."),
    phone: yep
      .string()
      .required("Phone number is required.")
      .max(10, "Should not exceed 10 characters.")
      .min(10, "Please enter a valid phone number."),
  });

  return (
    <Box className={classes.bannerbox}>
      <Container maxWidth="lg">
        <Box className={classes.mainbox}>
          <Formik
            initialValues={formInitialSchema}
            initialStatus={{
              success: false,
              successMsg: "",
            }}
            validationSchema={formValidationSchema}
          >
            {({
              errors,
              handleBlur,
              handleChange,
              handleSubmit,
              touched,
              values,
              setFieldValue,
            }) => (
              <Form>
                <Grid container spacing={2}>
                  <Box className={classes.updateBox}>
                    <Typography variant="h2">Edit Profile</Typography>
                    <br />
                   
                  </Box>
                  <Grid item lg={12} md={12} xs={12} sm={12}>
                    <Box mt={2}>
                    <Box paddingBottom="5px">
                      <Typography variant="body2"> Full Name</Typography>
                      </Box>
                      <TextField
                      type="text"
                      className={classes.textBox}
                      placeholder="First name"
                      variant="outlined"
                      fullWidth
                      name="firstname"
                      id="firstname"
                      value={values.firstname}
                      error={Boolean(
                        touched.firstname && errors.firstname
                      )}
                      onBlur={handleBlur}
                      onChange={handleChange}
                    />

                    <FormHelperText error>
                      {touched.firstname && errors.firstname}
                    </FormHelperText>
                    </Box>
                  </Grid>
                  <Grid item lg={12} md={12} xs={12} sm={12}>
                    <Box>
                    <Box paddingBottom="5px">
                      <Typography variant="body2"> Email address</Typography>
                      </Box>
                      <TextField
                      type="text"
                      className={classes.textBox}
                      placeholder="Email address"
                      variant="outlined"
                      fullWidth
                      name="email"
                      id="email"
                      value={values.email}
                      error={Boolean(touched.email && errors.email)}
                      onBlur={handleBlur}
                      onChange={handleChange}
                    />

                    <FormHelperText error>
                      {touched.email && errors.email}
                    </FormHelperText>
                    </Box>
                  </Grid>
                  <Grid item lg={12} md={12} xs={12} sm={12}>
                    <Box>
                    <Box paddingBottom="5px">
                      <Typography variant="body2"> Phone Number</Typography>
                      </Box>
                      {/* <ThemeProvider theme={theme}> */}
                      <FormControl style={{ width: "100%" }}>
                      <OutlinedInput
                        name="phone"
                        value={values.phone}
                        error={Boolean(touched.phone && errors.phone)}
                        onBlur={handleBlur}
                        onChange={handleChange}
                        id="outlined-adornment-amount"
                        className={classes.textBox}
                        placeholder="Phone Number"
                        startAdornment={
                          <InputAdornment position="start">
                            <InputLabel>
                              {" "}
                              <span
                                style={{ color: "rgb(103, 103, 103)" }}
                              >
                                {" "}
                                +91{" "}
                              </span>{" "}
                            </InputLabel>
                          </InputAdornment>
                        }
                      />
                    </FormControl>
                    {/* </ThemeProvider> */}
                    <FormHelperText error className={classes.helperText}>
                      {touched.phone && errors.phone}
                    </FormHelperText>
                    </Box>
                  </Grid>
                  <Grid item lg={12} md={12} xs={12} sm={12}>
                    <Box>
                    <Box paddingBottom="5px">
                      <Typography variant="body2"> Password</Typography>
                      </Box>
                      <TextField
                      className={classes.textBox}
                      InputProps={{
                        endAdornment: (
                          <IconButton
                          style={{ color: "#CBCBCB" }}
                            position="end"
                            aria-label="toggle password visibility"
                            onClick={() => setShowPassword(!showPassword)}
                            // onMouseDown={handleMouseDownPassword}
                            edge="end"
                          >
                            {showPassword ? (
                              <Visibility />
                            ) : (
                              <VisibilityOff />
                            )}
                          </IconButton>
                        ),
                      }}
                      type={showPassword ? "text" : "password"}
                      placeholder="Password"
                      variant="outlined"
                      fullWidth
                      name="password"
                      id="password"
                      value={values.password}
                      error={Boolean(touched.password && errors.password)}
                      onBlur={handleBlur}
                      onChange={handleChange}
                    />

                    <FormHelperText error>
                      {touched.password && errors.password}
                    </FormHelperText>
                    </Box>
                  </Grid>
                  <Grid item lg={12} md={12} xs={12} sm={12}>
                    
                    <Box paddingBottom="5px">
                      <Typography variant="body2"> Confirm Password</Typography>
                      </Box>
                      <TextField
                            className={classes.textBox}
                            InputProps={{
                              endAdornment: (
                                
                                <IconButton
                                style={{ color: "#CBCBCB" }}
                                  position="end"
                                  aria-label="toggle password visibility"
                                  onClick={() =>
                                    setshowConfirmPassword(!showConfirmPassword)
                                  }
                                  // onMouseDown={handleMouseDownPassword}
                                  edge="end"
                                >
                                  {showConfirmPassword ? (
                                    <Visibility />
                                  ) : (
                                    <VisibilityOff />
                                  )}
                                </IconButton>
                              ),
                            }}
                            type={showConfirmPassword ? "text" : "password"}
                            placeholder="Confirm Password"
                            variant="outlined"
                            fullWidth
                            name="confirmPassword"
                            id="confirmPassword"
                            value={values.confirmPassword}
                            error={Boolean(
                              touched.confirmPassword && errors.confirmPassword
                            )}
                            onBlur={handleBlur}
                            onChange={handleChange}
                          />
                          <FormHelperText error>
                            {touched.confirmPassword && errors.confirmPassword}
                          </FormHelperText>
                   
                  </Grid>
                  <Grid item lg={12} md={12} xs={12} sm={12}>
                    <Box>
                      <FormControl
                        component="fieldset"
                        style={{ display: "flex" }}
                        fullWidth
                      >
                        <RadioGroup
                          aria-label="gender"
                          name="gender1"
                          value={value}
                          onChange={handleChange}
                        >
                          <FormControlLabel
                            value="female"
                            control={<Radio />}
                            label="Female"
                          />
                          <FormControlLabel
                            value="male"
                            control={<Radio />}
                            label="Male"
                          />
                        </RadioGroup>
                      </FormControl>
                    </Box>
                  </Grid>
                  <Grid item lg={12} md={12} xs={12} sm={12}>
                    <Box>
                    <Box paddingBottom="5px">
                      <Typography variant="body2">
                    
                        Residential address
                      </Typography>
                      </Box>
                      <TextField
                      className={classes.textBox}
                        placeholder="Enter Residential address "
                        type="text"
                        variant="outlined"
                        fullWidth
                        size="fulll"
                        name="email"
                      />
                    </Box>
                  </Grid>
                  <Grid item lg={6} md={6} xs={6} sm={6}>
                    <Box>
                    <Box paddingBottom="5px">
                      <Typography variant="body2">City</Typography>
                      </Box>
                      <TextField
                      className={classes.textBox}
                        placeholder="Enter city"
                        type="text"
                        variant="outlined"
                        fullWidth
                        size="fulll"
                        name="email"
                      />
                    </Box>
                  </Grid>
                  <Grid item lg={6} md={6} xs={6} sm={6}>
                    <Box>
                    <Box paddingBottom="5px">
                      <Typography variant="body2"> State</Typography>
                      </Box>
                      <TextField
                      className={classes.textBox}
                        placeholder="Enter State"
                        type="text"
                        variant="outlined"
                        fullWidth
                        size="fulll"
                        name="email"
                      />
                    </Box>
                  </Grid>
                  <Grid item lg={6} md={6} xs={6} sm={6}>
                    <Box>

                    <Box paddingBottom="5px">
                      <Typography variant="body2">City</Typography>
                      </Box>
                      <TextField
                      className={classes.textBox}
                        placeholder="Enter City"
                        type="text"
                        variant="outlined"
                        fullWidth
                        size="fulll"
                        name="email"
                      />
                    </Box>
                  </Grid>
                  <Grid item lg={6} md={6} xs={6} sm={6}>
                    <Box>
                    <Box paddingBottom="5px">
                      <Typography variant="body2"> state</Typography>
                      </Box>
                      <TextField
                      className={classes.textBox}
                        placeholder="Enter State"
                        type="text"
                        variant="outlined"
                        fullWidth
                        size="fulll"
                        name="email"
                      />
                    </Box>
                  </Grid>

                  <Grid item lg={12} md={12} xs={12} sm={12}>
                    <Button
                      variant="outlined"
                      fullWidth
                      color="#fff"
                      style={{
                        padding: "10px",
                        backgroundColor: "#6FCFB9",
                        color: "white",
                        borderRadius: "12px",
                      }}
                      type="submit"
                      component={Link}
                      to="/"
                    >
                
                    Update
                    </Button>
                  </Grid>
                  
                </Grid>
              </Form>
            )}
          </Formik>
        </Box>
      </Container>
    </Box>
  );
}

export default Banner;
