import React, { } from "react";
import {
  Box,
  Typography,
  Container,
  Grid,
  Button,
  TextField,
  FormHelperText
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core";
import "animate.css";
import { Link } from "react-router-dom";
import * as yep from "yup";
import { Form, Formik } from "formik";

const useStyles = makeStyles((theme) => ({
  bannerbox: {
    paddingTop: "50px",
    color: "#000",
    paddingBottom: "70px",
    //background:"lightgreen",
     minHeight:"300px",
  },
  mainbox: {
    background: "rgba(255, 255, 255, 0.6)",
    boxShadow: "0px 0px 26px rgba(0, 0, 0, 0.1)",
    borderRadius: "20px",
    padding: "80px",
    minHeight:"425px"
  },
  textBox:{
    background:"#fff"
  }
}));
function Banner() {
  const classes = useStyles();
  const [value, setValue] = React.useState("female");

  const handleChange = (event) => {
    setValue(event.target.value);
  };
  const formInitialSchema = {
    email: "",
 
  };
 
  const formValidationSchema = yep.object().shape({
    email: yep
      .string()
      .email("Please enter valid email address.")
      .required("Please enter valid email address."),
   
  });
  return (
    <Box className={classes.bannerbox}>
      <Container maxWidth="lg">
      <Formik
          initialValues={formInitialSchema}
          initialStatus={{
            success: false,
            successMsg: "",
          }}
          validationSchema={formValidationSchema}
          onSubmit={(values) =>(values)}
        >
          {({
            errors,
            handleBlur,
            handleChange,
            handleSubmit,
            touched,
            values,
            setFieldValue,
          }) => (
            <Form>
        <Box className={classes.mainbox}>
          <Grid container spacing={2}>
          <Box paddingLeft="10px">
            <Typography variant="h2">Forgot Password?</Typography>
            <br     />
            <Typography variant="body1"> <span style={{ color: "rgb(83, 83, 83,1)" }}>
            Please enter your registered email here and we will send OTP to reset your password. </span>
            </Typography>   
            </Box>

            <Grid item lg={12} md={12} xs={12} sm={12}>
           
            
              <Box mt={4}>
              <Box paddingBottom="5px" mt={8}>
              <Typography variant="body2"> <span style={{ color: "rgb(83, 83, 83,1)" }}>Email address </span> </Typography>
              </Box>
              <TextField
              className={classes.textBox}
              type="text"
             // disabled={isLoading}
              placeholder="Enter Your Email"
              variant="outlined"
              fullWidth
              name="email"
              id="email"
              value={values.email}
              error={Boolean(touched.email && errors.email)}
              onBlur={handleBlur}
              onChange={handleChange}
            />

            <FormHelperText error className={classes.helperText}>
              {touched.email && errors.email}
            </FormHelperText>
              </Box>
            </Grid>

            
          

            <Grid item lg={12} md={12} xs={12} sm={12}>
            <Box mt={1}>
              <Button 
            
                variant="outlined"
                fullWidth
                color="#fff"
                style={{
                  padding: "10px",
                  backgroundColor: "#6FCFB9",
                  color: "white",
                  borderRadius:"12px",
            
                }}
                type="submit" component={Link}
                to="/Otpforgot"
              >
                Send
              </Button>
              </Box>
            </Grid>
           
          </Grid>
                
      </Box>
      </Form>
          )}
        </Formik>
      </Container>
    </Box>
  );
}

export default Banner;

