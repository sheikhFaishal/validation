import React, { useState } from "react";
import {
  Box,
  Typography,
  Container,
  Grid,
  Button,
  TextField,
  FormControl,
  IconButton,
  InputAdornment,
  FormHelperText,
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core";
import "animate.css";
import * as yep from "yup";
import { Form, Formik } from "formik";
import Visibility from "@material-ui/icons/Visibility";
import VisibilityOff from "@material-ui/icons/VisibilityOff";
import { Link } from "react-router-dom";

const useStyles = makeStyles((theme) => ({
  bannerbox: {
    paddingTop: "70px",
    color: "#000",
    paddingBottom: "50px",
  },
  mainbox: {
    background: "rgba(255, 255, 255, 0.6)",
    boxShadow: "0px 0px 26px rgba(0, 0, 0, 0.1)",
    borderRadius: "20px",
    padding: "80px",
    minHeight: "425px",
  },
  textBox: {
    backgroundColor: "#fff",
  },
}));
function Banner() {
  const classes = useStyles();
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  // const [value, setValue] = React.useState("female");

  const formInitialSchema = {
    password: "",
    confirmPassword: "",
  };

  const formValidationSchema = yep.object().shape({
    password: yep
      .string()
      .required("Password is required.")
      .min(6, "Minimum 6 characters required.")
      .max(16, "Maximum 16 characters required."),

    confirmPassword: yep
      .string()
      .required("Confirm password is required.")
      .oneOf(
        [yep.ref("password"), null],
        "Confirm password or password did not match."
      ),
  });

  return (
    <Box className={classes.bannerbox}>
      <Container maxWidth="lg">
        <Formik
          initialValues={formInitialSchema}
          initialStatus={{
            success: false,
            successMsg: "",
          }}
          validationSchema={formValidationSchema}
          onSubmit={(values) => values}
        >
          {({
            errors,
            handleBlur,
            handleChange,
            handleSubmit,
            touched,
            values,
            setFieldValue,
          }) => (
            <Form>
              <Box className={classes.mainbox}>
                <Grid container spacing={1}>
                  <Box paddingLeft="8px">
                    <Typography variant="h2">Reset Password</Typography>
                    <br />
                    <Typography variant="body1">
                      {" "}
                      <span style={{ color: "rgb(83, 83, 83,1)" }}>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                        Arcu ultrices tortor felis, aliquet..{" "}
                      </span>
                    </Typography>
                  </Box>

                  <Grid item lg={12} md={12} xs={12} sm={12}>
                    <Box mt={5}>
                      <Typography variant="body2">New password</Typography>
                    </Box>
                    <Box mt={1}>
                      <Box paddingBottom="2px">
                        <FormControl className="passwordControl" fullWidth>
                          <TextField
                            className={classes.textBox}
                            name="password"
                            value={values.password}
                            type={showPassword ? "text" : "password"}
                            label=""
                            variant="outlined"
                            placeholder="Enter your New password"
                            fullWidth
                            error={Boolean(
                              touched.Oldpassword && errors.Oldpassword
                            )}
                            onChange={handleChange}
                            onBlur={handleBlur}
                            InputProps={{
                              autoComplete: "new-password",
                              form: {
                                autoComplete: "off",
                              },

                              endAdornment: (
                                <InputAdornment position="end">
                                  <IconButton
                                    style={{ color: "#CBCBCB" }}
                                    onClick={() =>
                                      setShowPassword(!showPassword)
                                    }
                                    edge="end"
                                  >
                                    <Box>
                                      {showPassword ? (
                                        <Visibility
                                          style={{
                                            fontSize: "20px",
                                            display: "flex",
                                            justifyContent: "center",
                                            alignItems: "center",
                                          }}
                                        />
                                      ) : (
                                        <VisibilityOff
                                          style={{
                                            fontSize: "20px",
                                            display: "flex",
                                            justifyContent: "center",
                                            alignItems: "center",
                                          }}
                                        />
                                      )}
                                    </Box>
                                  </IconButton>
                                </InputAdornment>
                              ),
                            }}
                          />
                          <FormHelperText style={{ color: "red" }}>
                            {touched.password && errors.password}
                          </FormHelperText>
                        </FormControl>
                      </Box>
                    </Box>
                  </Grid>

               
                  <Grid item lg={12} md={12} xs={12} sm={12}>
                    <Box>
                      <Typography variant="body2">  Confirm password</Typography>
                    </Box>
                    <Box mt={1}>
                      <Box paddingBottom="2px">
                        <FormControl className="cpasswordField" fullWidth>
                          <TextField
                            className={classes.textBox}
                            name="confirmPassword"
                            value={values.confirmPassword}
                            type={showConfirmPassword ? "text" : "password"}
                            label=""
                            variant="outlined"
                            placeholder="Enter confirm password"
                            fullWidth
                            error={Boolean(
                              touched.confirmPassword && errors.confirmPassword
                            )}
                            onChange={handleChange}
                            onBlur={handleBlur}
                            InputProps={{
                              autoComplete: "new-password",
                              form: {
                                autoComplete: "off",
                              },

                              endAdornment: (
                                <InputAdornment position="end">
                                  <IconButton
                                    style={{ color: "#CBCBCB" }}
                                    onClick={() =>
                                      setShowConfirmPassword(!showConfirmPassword)
                                    }
                                    edge="end"
                                  >
                                    <Box>
                                      {showConfirmPassword ? (
                                        <Visibility
                                          style={{
                                            fontSize: "20px",
                                            display: "flex",
                                            justifyContent: "center",
                                            alignItems: "center",
                                          }}
                                        />
                                      ) : (
                                        <VisibilityOff
                                          style={{
                                            fontSize: "20px",
                                            display: "flex",
                                            justifyContent: "center",
                                            alignItems: "center",
                                          }}
                                        />
                                      )}
                                    </Box>
                                  </IconButton>
                                </InputAdornment>
                              ),
                            }}
                          />
                          <FormHelperText style={{ color: "red" }}>
                            {touched.confirmPassword && errors.confirmPassword}
                          </FormHelperText>
                        </FormControl>
                      </Box>
                    </Box>
                  </Grid>

                  <Grid item lg={12} md={12} xs={12} sm={12}>
                    <Box mt={1}>
                      <Button
                        variant="outlined"
                        fullWidth
                        color="#fff"
                        style={{
                          padding: "10px",
                          backgroundColor: "#6FCFB9",
                          color: "white",
                          borderRadius: "12px",
                        }}
                        type="submit"
                        component={Link}
                        to="/Login"
                      >
                        Submit
                      </Button>
                    </Box>
                  </Grid>
                </Grid>
              </Box>
            </Form>
          )}
        </Formik>
      </Container>
    </Box>
  );
}

export default Banner;
