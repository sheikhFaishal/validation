import React from 'react'
import {
    Box,
    Typography,
    Container,
    Grid,
    Button,
    TextField,
    FormHelperText
  } from "@material-ui/core";
  import { makeStyles } from "@material-ui/core";
  import "animate.css";
  import * as Yup from "yup";
  import { Link } from "react-router-dom";
  import { Form, Formik } from "formik";
  const useStyles = makeStyles((theme) => ({
    bannerbox: {
      paddingTop: "50px",
      color: "#000",
      paddingBottom: "70px",
      //background:"lightgreen",
      // minHeight:"300px",
    },
    mainbox: {
      background: "rgba(255, 255, 255, 0.6)",
      boxShadow: "0px 0px 26px rgba(0, 0, 0, 0.1)",
      borderRadius: "20px",
      padding: "80px",
      minHeight:"425px"
    },
    textBox:{
      background:"#fff"
    }
  }));
export default function Otpforgot() {
    const classes = useStyles();
    const [value, setValue] = React.useState("female");
  
    const handleChange = (event) => {
      setValue(event.target.value);
    };
    const formInitialvalue = {
      otp: "",
    };
    const fromValidation = Yup.object().shape({
      otp: Yup.string()
  
        .required("OTP is required")
        .matches(/^[0-9]*$/, "Must be a valid OTP")
        .max(4, "Should not exceeds 4 digits")
        .min(4, "Must be only 4 digits"),
    });

  return (
    <Box className={classes.bannerbox}>
    <Container maxWidth="lg">
    <Formik
        initialValues={formInitialvalue}
        initialStatus={{
          success: false,
          successMed: "successfull",
        }}
        validationSchema={fromValidation}
        onSubmit={(values) =>(values)}
      >
        {({
          errors,
          handleBlur,
          handleChange,
          handleSubmit,
          touched,
          values,
          setFieldValue,
          o,
        }) => (
          <Form
            onSubmit={handleSubmit}
            style={{ width: "100%" }}
            className={classes.formControl}
          >
      <Box className={classes.mainbox}>
        <Grid container spacing={2}>
        <Box paddingLeft="10px">
          <Typography variant="h2">Verify OTP?</Typography>
          <br     />
          <Typography variant="body1"> <span style={{ color: "rgb(83, 83, 83,1)" }}>
          OTP has been sent to abc@gmail.com <br/>
Please enter the OTP.</span>
          </Typography>   
          </Box>

          <Grid item lg={12} md={12} xs={12} sm={12}>
         
          
            <Box mt={4}>
            <Box paddingBottom="5px">
            <Typography variant="body2"> <span style={{ color: "rgb(83, 83, 83,1)" }}>OTP </span> </Typography>
            </Box>
            <TextField
                    className={classes.textBox}
                    type="text"
                    placeholder="verify Otp"
                    variant="outlined"
                    fullWidth
                    id="otp"
                    value={values.otp}
                    error={Boolean(touched.otp && errors.otp)}
                    onBlur={handleBlur}
                    onChange={handleChange}
                  />

                  <FormHelperText error className={classes.helperText}>
                    {touched.otp && errors.otp}
                  </FormHelperText>
            </Box>
          </Grid>

          
        

          <Grid item lg={12} md={12} xs={12} sm={12}>
          <Box mt={1}>
            <Button
              variant="outlined"
              fullWidth
              color="#fff"
              style={{
                padding: "10px",
                backgroundColor: "#6FCFB9",
                color: "white",
                borderRadius:"12px",
          
              }}
              type="submit" component={Link}
              to="/Reset"
            >
            
            Verify OTP
            </Button>
            </Box>
          </Grid>
         
        </Grid>
              
    </Box>
    </Form>
        )}
      </Formik>
    </Container>
  </Box>
);
}