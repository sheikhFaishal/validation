import React from "react";
import {
  Box,
  Container,
  Grid,
  Typography,
  TextField,
  Button,
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core";
import Avatar from "@material-ui/core/Avatar";
//import Typography from "@/theme/typography";
//import GoComment from "react-icons/go";
import AvatarGroup from "@material-ui/lab/AvatarGroup";
import { BiShare } from "react-icons/bi";
import { AiOutlineHeart } from "react-icons/ai";
import { BiCommentDetail } from "react-icons/bi";
import { RiSendPlane2Line } from "react-icons/ri";
const useStyles = makeStyles((theme) => ({
  bannerbox: {
    paddingTop: "160px",
    color: "#000",
    paddingBottom: "70px",
    background: "#f5f5f5",
    // height: "120vh",
  },
  imageBox: {
    //borderRadius: "12px",
    minHeight: "210px",
    //border: "1px solid black",
    // display: "flex",
    padding: "20px",
  },
  bannerboxx: {
    paddingTop: "10px",
    color: "#000",
    paddingBottom: "30px",
    background: "#ffff",
  },
  textBox: {
    width: "100%",
    marginTop: "15px",
  },
  iconsBox: {
    display: "flex",
    justifyContent: "space-between",
    paddingBottom: "10px",
  //  border: "1px solid black",
    padding: "14px 10px",
  },
}));

export default function Ali() {
  const classes = useStyles();
  return (
    <Grid item xs={12} md={12}>
      <Box className={classes.bannerbox}>
        <Container maxWidth="md">
          <Box className={classes.bannerboxx}>
            <Box className={classes.imageBox}>
              <Box display="flex">
                <Box>
                  <Avatar alt="Remy Sharp" src="/images/umar.png" />
                </Box>
                <Box paddingLeft="10px">
                  <Typography variant="h5"> Umair Siddiqui</Typography>
                  <Typography variant="body1">2h ago</Typography>
                </Box>
              </Box>
              <Box className={classes.textBox}>
                <Typography variant="body1">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Adipiscing tincidunt ac sed egestas. Ultrices Lorem ipsum
                  dolor sit amet, consectetur adipiscing elit. Adipiscing
                  tincidunt ac sed egestas. Ultrices...
                </Typography>
              </Box>

              <Box paddingTop="15px">
                <img src="images/doogy.png" alt="images" width="100%" />
              </Box>
              <Box display="flex" justifyContent="space-between" margin="10px">
                <Box display="flex">
                  <AvatarGroup max={4}>
                    <Avatar alt="Remy Sharp" src="/images/av.png" />
                    <Avatar alt="Travis Howard" src="/images/ava.png" />
                    <Avatar alt="Cindy Baker" src="/images/avaa.png" />
                  </AvatarGroup>
                </Box>

                <Box display="flex" mt={2}>
                  <Box paddingRight="12px">
                    <Typography variant="body2">3 Comments</Typography>
                  </Box>
                  <Typography variant="body2">17 Share</Typography>
                </Box>
              </Box>
              <Box className={classes.iconsBox}>
                <Box display="flex">
                  <Typography variant="body1">Like</Typography>
                  <AiOutlineHeart />
                </Box>
                <Box display="flex">
                  <BiCommentDetail />
                  <Typography variant="body1">Comments</Typography>
                </Box>
                <Box display="flex">
                  <BiShare />
                  <Typography variant="body1">Share</Typography>
                </Box>
              </Box>
              <Box display="flex" mt={2}>
                <Box paddingRight="10px">
                  <Avatar alt="Remy Sharp" src="/images/cat.png" />
                </Box>
                <Box paddingRight="10px" marginTop="10px">
                  <Typography variant="body6">aliciamarks</Typography>
                </Box>
                <Box marginTop="10px">
                  <Typography variant="body2">
                    {" "}
                    So cool, I also want to do a bike ride!
                  </Typography>
                </Box>
              </Box>
              <Box display="flex" mt={2}>
                <Box paddingRight="10px">
                  <Avatar alt="Remy Sharp" src="/images/catt.png" />
                </Box>
                <Box paddingRight="10px" marginTop="10px">
                  <Typography variant="body6">jungtaekw </Typography>
                </Box>
                <Box marginTop="10px">
                  <Typography variant="body2">
                    {" "}
                    haha, looks very fun 😂
                  </Typography>
                </Box>
              </Box>
              <Box marginTop="10px" display="flex">
                <Avatar alt="Remy Sharp" src="/images/dip.png" />

                <TextField
                  placeholder="Write a comment..."
                  type="text"
                  variant="outlined"
                  fullWidth
                  size="Write a comment..."
                  name="Write a comment..."
                />
                <Box paddingLeft="10px" minHeight="10px">
                  <Button
                    type="submit"
                    variant="outlined"
                    fullWidth
                    color="#fff"
                    style={{
                      padding: "10px",
                      backgroundColor: "#6FCFB9",
                      color: "white",
                      
                    }}
                  >
                    <RiSendPlane2Line />
                  </Button>
                </Box>
              </Box>
            </Box>
          </Box>
        </Container>
      </Box>
    </Grid>
  );
}
