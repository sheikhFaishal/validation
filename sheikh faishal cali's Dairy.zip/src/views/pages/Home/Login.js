import React, { useState, } from "react";
import {
  Box,
  Typography,
  Container,
  Grid,
  Button,
  Checkbox,
  FormHelperText,
  TextField,
  IconButton
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core";
import "animate.css";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import { Link } from "react-router-dom";
import * as yep from "yup";
import { Form, Formik } from "formik";
import Visibility from "@material-ui/icons/Visibility";
import VisibilityOff from "@material-ui/icons/VisibilityOff";
const useStyles = makeStyles((theme) => ({
  bannerbox: {
    paddingTop: "120px",
    color: "#000",
    paddingBottom: "70px",
    //background:"lightgreen",
     minHeight:"400px",
    
  },
  mainbox: {
    background: "rgba(255, 255, 255, 0.6)",
    boxShadow: "0px 0px 26px rgba(0, 0, 0, 0.1)",
    borderRadius: "20px",
    padding: "40px",
    minHeight:"50px",
  
  
  },
  textBox:{
    borderRadius:"8px",
    backgroundColor:"#FFF",
  }
}));
function Banner() {
  const classes = useStyles();
  const [showPassword, setShowPassword] = useState(false);  
  const [value, setValue] = React.useState("female");
  const formInitialSchema = {
    email: "",
    password: "",
  }
  const formValidationSchema = yep.object().shape({
    email: yep
      .string()
      .email("Please enter a valid email address.")
      .required("Email is required."),
    password: yep
      .string()
      .required("Password is required.")
      
      .min(6, "Please enter atleast 6 characters.")
      .max(16, "You can enter only 16 characters."),
  });
  const handleChange = (event) => {
    setValue(event.target.value);
  };

  return (
    <Box className={classes.bannerbox}>
      <Container maxWidth="lg">
      <Formik
        initialValues={formInitialSchema}
        initialStatus={{
          success: false,
          successMsg: "",
        }}
        validationSchema={formValidationSchema}
        onSubmit={(values) => (values)}
      >
        {({
          errors,
          handleBlur,
          handleChange,
          handleSubmit,
          touched,
          values,
          setFieldValue,
        }) => (
          <Form>
        <Box className={classes.mainbox}>
          <Grid container spacing={1}>
          <Box paddingLeft="10px">
            <Typography variant="h2">Login</Typography>
            <br/>
            <Typography variant="body1"> <span style={{ color: "rgb(83, 83, 83,1)" }}>
              Login to Find your Perfect Campanion </span>
            </Typography>   
            </Box>

            <Grid item lg={12} md={12} xs={12} sm={12}>

              <Box mt={2}>
              <Box paddingBottom="5px">
                <Typography variant="body2"> Email address</Typography>
                </Box>
                <TextField
                            type="text"
                            className={classes.textBox}
                            placeholder="Email address"
                            variant="outlined"
                            fullWidth
                            name="email"
                            id="email"
                            value={values.email}
                            error={Boolean(touched.email && errors.email)}
                            onBlur={handleBlur}
                            onChange={handleChange}
                          />

                          <FormHelperText error>
                            {touched.email && errors.email}
                          </FormHelperText>
              </Box>
            </Grid>

            <Grid item lg={12} md={12} xs={12} sm={12}>
              <Box>
              <Box paddingBottom="5px">
                <Typography variant="body2"> Password</Typography>
                </Box>
                <TextField
                className={classes.textBox}
                InputProps={{
                  endAdornment: (
                    <IconButton
                    style={{ color: "#CBCBCB" }}
                      position="end"
                      aria-label="toggle password visibility"
                      onClick={() => setShowPassword(!showPassword)}
                      // onMouseDown={handleMouseDownPassword}
                      edge="end"
                    >
                      {showPassword ? (
                        <Visibility />
                      ) : (
                        <VisibilityOff />
                      )}
                    </IconButton>
                  ),
                }}
                type={showPassword ? "text" : "password"}
                placeholder="Password"
                variant="outlined"
                fullWidth
                name="password"
                id="password"
                value={values.password}
                error={Boolean(touched.password && errors.password)}
                onBlur={handleBlur}
                onChange={handleChange}
              />

              <FormHelperText error>
                {touched.password && errors.password}
              </FormHelperText>
              </Box>
            </Grid>
            <Grid
              item
              lg={12}
              md={12}
              sm={12}
              xs={12}
              style={{ display: "flex", justifyContent: "space-between" }}
            >
              <Box
                display="flex"
                justifyContent="space-between"
                paddingLeft="10px"
              >
                <FormControlLabel control={<Checkbox name="checkedC" />} />
                <Box marginTop="5px">
                  <Typography variant="body1"> Remember me</Typography>
                </Box>
              </Box>
              <Box marginTop="5px">
                <Typography variant="body1" component={Link}
                to="/Forgot"> Forgot password ?</Typography>
              </Box>
            </Grid>

            <Grid item lg={12} md={12} xs={12} sm={12}>
              <Button
              type="submit"
                variant="outlined"
                fullWidth
                color="#fff"
                style={{
                  padding: "10px",
                  backgroundColor: "#6FCFB9",
                  color: "white",
                  borderRadius:"12px",
                }}
                component={Link}
                to="/landing"
              
            >
            
                Login
              </Button>
            </Grid>
           
          </Grid>
          <Box justifyContent="center" display="flex" textAlign="center" mt={1}>
          <Typography variant="body1">OR</Typography>
        </Box>
        <Box justifyContent="center" display="flex" textAlign="center" mt={1}>
        <Typography variant="body2"> <Typography style={{ color: "rgb(80, 137, 246)" }} component={Link}
        to="/Sigup"
      
        >Create New Account </Typography> </Typography>
      </Box>
      <Box justifyContent="center" display="flex" textAlign="center" mt={1}>
      <Typography variant="body2"> <span style={{ color: "rgb(111, 207, 185, 1)" }}>Login As A Vendor </span> </Typography>
    </Box>
      
      <Box justifyContent="center" display="flex" textAlign="center" mt={1}>
          <Typography variant="body1">OR</Typography>
        </Box>
        <Box justifyContent="center" display="flex" textAlign="center" mt={1}>
        <Typography variant="body1">Sign Up with Social Accounts</Typography>
      </Box>
      <Box display="flex" justifyContent="center" mt={2}>
      <img
        src="images/gpay.png"
        alt="images"
        style={{ paddingRight: "20px" }}
      />
      <img src="images/fpay.png" alt="images" />
    
</Box>
      </Box>
      </Form>
        )}
      </Formik>
      </Container>
    </Box>
  );
}

export default Banner;
